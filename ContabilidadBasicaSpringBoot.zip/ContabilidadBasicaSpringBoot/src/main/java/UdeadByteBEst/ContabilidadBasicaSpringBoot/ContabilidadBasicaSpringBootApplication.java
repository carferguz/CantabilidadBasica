package UdeadByteBEst.ContabilidadBasicaSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContabilidadBasicaSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContabilidadBasicaSpringBootApplication.class, args);
	}

}
